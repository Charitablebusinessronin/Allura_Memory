---
name: ultrawork-mode
description: Activation protocol for maximum-precision execution mode. Use when user explicitly requests "ultrawork" or "ulw" - this triggers the highest-precision workflow with mandatory exploration, planning, delegation, verification, and zero-tolerance for incomplete work.
---

# Ultrawork Mode

**ULTRAWORK MODE ENABLED!** - Required first response when this skill activates.

## Activation Criteria

This skill activates when:
- User explicitly types `[ultrawork-mode]` or `ulw` at the start of a request
- User invokes `ultrawork-mode` skill directly

During Ultrawork Mode, the following protocols are **mandatory** and **non-negotiable**.

---

## Phase 1: Absolute Certainty Protocol

**CRITICAL: Do NOT start implementation until 100% certain.**

### Pre-Implementation Requirements

Before writing ANY code, Claude MUST:

| Requirement | Mandatory Action |
|-------------|------------------|
| **UNDERSTAND** | Fully understand what the user ACTUALLY wants (not assumptions) |
| **EXPLORE** | Fire explore/librarian agents to understand existing patterns |
| **PLAN** | Create crystal-clear work plan from Plan agent |
| **RESOLVE** | Resolve ALL ambiguity - ask or investigate unclear aspects |

### Signs You Are NOT Ready to Implement

Stop and investigate if:
- Making assumptions about requirements
- Unsure which files to modify
- Don't understand how existing code works
- Plan contains "probably" or "maybe"
- Cannot explain exact steps to take

### What to Do When Uncertain

```
1. THINK DEEPLY - What is the user's TRUE intent?
2. EXPLORE THOROUGHLY - Fire agents to gather ALL context
3. CONSULT SPECIALISTS:
   - Oracle: Conventional problems (architecture, debugging)
   - Artistry: Non-conventional problems (unusual constraints)
4. ASK THE USER - If ambiguity remains, ASK. Never guess.
```

---

## Phase 2: Parallel Context Gathering

**DEFAULT BEHAVIOR: Fire multiple agents IN PARALLEL.**

### Mandatory Agent Deployment

```typescript
// ALWAYS deploy explore/librarian when context is needed
task(subagent_type="explore", load_skills=[], run_in_background=true, prompt="...")
task(subagent_type="explore", load_skills=[], run_in_background=true, prompt="...")
task(subagent_type="librarian", load_skills=[], run_in_background=true, prompt="...")

// NEVER wait for one to finish before starting others
// NEVER manually search for information delegated to agents
```

### Context Gathering Rules

| When | Number of Agents |
|------|-----------------|
| Codebase patterns needed | 1-3 explore agents (background) |
| External library/docs | 1-2 librarian agents (background) |
| Complex architecture | Consult oracle directly |
| Non-conventional approach | Consult artistry agent |

### Delegation Trust Rule

Once you fire an agent for a search task, **do NOT perform that same search yourself.**

- Use direct tools only for non-overlapping work
- Continue with independent tasks while agents run
- End response and wait for system notification when results are needed

---

## Phase 3: Mandatory Plan Agent Invocation

**YOU MUST ALWAYS CALL THE PLAN AGENT for non-trivial tasks.**

### Plan Agent is NON-NEGOTIABLE When:

| Condition | Action |
|-----------|--------|
| Task has 2+ steps | MUST invoke plan agent |
| Task scope unclear | MUST invoke plan agent |
| Implementation required | MUST invoke plan agent |
| Architecture decision needed | MUST invoke plan agent |

### Plan Agent Pattern

```typescript
// FIRST: Gather context via explore/librarian (parallel)
task(subagent_type="explore", load_skills=[], run_in_background=true, prompt="Find X...")
task(subagent_type="librarian", load_skills=[], run_in_background=true, prompt="Lookup Y...")

// THEN: Invoke plan with gathered context
task(subagent_type="plan", load_skills=[], prompt="<context from agents + user request>")
```

### Session Continuity (CRITICAL)

Use the returned `session_id` for follow-ups:

```typescript
// Plan agent returns session_id
const result = task(subagent_type="plan", ...)
const sessionId = result.session_id

// WRONG: Starting fresh loses all context
task(subagent_type="plan", load_skills=[], prompt="More info...") // ❌

// CORRECT: Resume preserves everything
task(session_id=sessionId, load_skills=[], prompt="Here's more info...") // ✅
```

---

## Phase 4: Category + Skills Delegation System

### Available Categories (Domain-Optimized)

| Category | When to Use |
|----------|-------------|
| `visual-engineering` | Frontend, UI/UX, CSS, animation, layout |
| `ultrabrain` | Genuinely hard, logic-heavy tasks |
| `deep` | Autonomous problem-solving with research |
| `artistry` | Non-conventional creative approaches |
| `quick` | Trivial single-file changes |
| `unspecified-low` | Low-effort tasks not fitting other categories |
| `unspecified-high` | High-effort tasks not fitting other categories |
| `writing` | Documentation, prose |

### Available Skills (Priority: User Skills > Built-in)

**User Skills (Priority):**
- browseros-odoo-sign
- faith-meats-workspace
- madappgang-claude-code-shadcn-ui
- data-transform
- ai-documentation
- Backend Models Standards
- systematic-debugging
- skill-creator

**Built-in Skills:**
- playwright
- frontend-ui-ux
- git-master
- dev-browser

### Delegation Pattern

```typescript
// ALWAYS select matching category and RELEVANT skills
task(
  category="visual-engineering",
  load_skills=["frontend-ui-ux", "relevant-user-skill"],
  run_in_background=true|false,
  prompt="..."
)
```

### Anti-Pattern

```typescript
// WRONG: Empty load_skills
task(category="quick", load_skills=[], prompt="...") // ❌

// CORRECT: Include ALL relevant skills
task(category="visual-engineering", load_skills=["frontend-ui-ux"], prompt="...") // ✅
```

---

## Phase 5: Implementation via Delegation

### CRITICAL: YOU DELEGATE, NOT IMPLEMENT

| You Want To Do | You MUST Do Instead |
|----------------|----------------------|
| Write code yourself | Delegate to `deep` or `unspecified-high` agent |
| Handle 3 changes sequentially | Spawn 3 agents in parallel |
| "Quickly fix one thing" | Still delegate - subagent is faster |

**Your value is orchestration, decomposition, quality control.**

### Delegation Prompt Structure (ALL 6 Sections Required)

```
1. TASK: Atomic, specific goal (one action per delegation)
2. EXPECTED OUTCOME: Concrete deliverables with success criteria
3. REQUIRED TOOLS: Explicit tool whitelist (prevents tool sprawl)
4. MUST DO: Exhaustive requirements - leave NOTHING implicit
5. MUST NOT DO: Forbidden actions - block rogue behavior
6. CONTEXT: File paths, existing patterns, constraints
```

### Post-Delegation Verification

ALWAYS verify after delegation:
1. Does it work as expected?
2. Does it follow existing codebase patterns?
3. Did expected result appear?
4. Did agent follow MUST DO and MUST NOT DO requirements?

---

## Phase 6: Verification Guarantee

**NOTHING is "done" without PROOF it works.**

### Success Criteria Definition

Before writing code, define:

| Criteria Type | Description | Example |
|---------------|-------------|---------|
| **Functional** | What behavior must work | "Button triggers API" |
| **Observable** | What can be measured | "Console shows 'success'" |
| **Pass/Fail** | Binary verification | "Returns 200 OK" |

Record in TODO/Task items as "QA: [how to verify]"

### Manual QA Mandate (NON-OPTIONAL)

| If change adds... | YOU MUST... |
|-------------------|-------------|
| CLI command | Run it with Bash, show output |
| Build output | Run build, verify files exist |
| API behavior | Call endpoint, show response |
| UI rendering | Describe what renders |
| New tool/hook | Test end-to-end |
| Config change | Load config, verify parsing |

### Unacceptable QA Claims

- "This should work" → **RUN IT.**
- "Types check out" → **Types don't catch logic bugs. RUN IT.**
- "lsp_diagnostics is clean" → **That's TYPE check. RUN IT.**
- "Tests pass" → **Does ACTUAL feature work? RUN IT.**

### TDD Workflow (When Infrastructure Exists)

1. **SPEC**: Define success criteria
2. **RED**: Write failing test → Confirm it FAILS
3. **GREEN**: Write minimal code → Confirm test PASSES
4. **REFACTOR**: Clean up → Tests stay green
5. **VERIFY**: Run full suite → No regressions
6. **EVIDENCE**: Report what was run and output seen

---

## Phase 7: Zero Tolerance Policy

### NO EXCUSES. NO COMPROMISES.

| Violation | Consequence |
|-----------|-------------|
| "I couldn't because..." | **UNACCEPTABLE.** Find a way. |
| "This is simplified..." | **UNACCEPTABLE.** Deliver FULL implementation. |
| "You can extend later..." | **UNACCEPTABLE.** Finish NOW. |
| "Due to limitations..." | **UNACCEPTABLE.** Use tools/agents. |
| "I assumed..." | **UNACCEPTABLE.** Ask first. |

### No Valid Excuses For:

- Delivering partial work
- Changing scope without explicit approval
- Making unauthorized simplifications
- Stopping before 100% complete
- Compromising on stated requirement
- Deleting failing tests

### If Encountering Blocker

1. **DO NOT** give up
2. **DO NOT** deliver compromised version
3. **DO** consult specialists (oracle/artistry)
4. **DO** ask user for guidance
5. **DO** explore alternative approaches

**USER ASKED FOR X. DELIVER EXACTLY X. PERIOD.**

---

## Workflow Summary

1. **Certainty Check** - Am I 100% certain? If NO → investigate
2. **Parallel Explore** - Fire 1-5 agents simultaneously (background)
3. **Plan Agent** - Invoke with gathered context, use session_id for continuity
4. **Delegate Work** - Category + skills matching, parallel execution
5. **Verify Evidence** - Manual QA, tests, builds with proof
6. **Complete 100%** - No partial, no excuses

---

## Quick Reference

### Agent Dispatch

| Agent | Use Case | Background? |
|-------|----------|-------------|
| explore | Codebase patterns | Yes (always) |
| librarian | External docs/libraries | Yes (always) |
| plan | Work breakdown | No (session-based) |
| oracle | Architecture/debugging | No (consultation) |
| artistry | Non-conventional | No (consultation) |

### Evidence Requirements

| Change Type | Evidence Required |
|-------------|-------------------|
| File edit | Clean `lsp_diagnostics` |
| Build | Exit code 0 |
| Test | All tests pass |
| Feature | Manual QA executed |
| Delegation | Result received & verified |

---

## Delegation Template

Standard delegation structure (copy-paste ready):

```markdown
1. TASK: [Atomic action]
2. EXPECTED OUTCOME: [Concrete deliverable + success criteria]
3. REQUIRED TOOLS: [Tool whitelist]
4. MUST DO:
   - [Exhaustive requirement 1]
   - [Exhaustive requirement 2]
   - [...]
5. MUST NOT DO:
   - [Forbidden action 1]
   - [Forbidden action 2]
6. CONTEXT: [Files, patterns, constraints]
```